# PRODIGY_DS_03-Intern-Pinaki-Jupyter-Lab-TASK-03
As an Intern, I have created and completed in 12-14 days in Jupyter Lab as per the task of Prodigy InfoTech i.e., DATA SCIENCE ----TASK 3.

Task : Build a decision tree classifier to predict whether a customer will purchase a product or service based on their demographic and behavioral data. Use a dataset such as the Bank Marketing dataset from the UCI Machine Learning Repository.



https://github.com/PINAKIMATHAN/PRODIGY_DS_03-Intern-Pinaki-Jupyter-Lab-TASK-03/assets/107812574/23d79871-d711-4460-977b-a3fc872f4e9f

